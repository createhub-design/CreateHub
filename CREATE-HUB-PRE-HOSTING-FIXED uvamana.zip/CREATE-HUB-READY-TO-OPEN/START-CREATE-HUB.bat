@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js 22 or newer is required. Install Node.js from https://nodejs.org/ and try again.& pause & exit /b 1)
start "CREATE HUB server" cmd /k "node server.js"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:3000/sg-creative-studio.html
