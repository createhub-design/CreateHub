@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or not on PATH.
  echo Install Node.js 22 or newer from https://nodejs.org/
  pause
  exit /b 1
)
echo Starting CREATE HUB local server...
start "CREATE HUB server - keep this window open" cmd /k "cd /d "%~dp0" && node server.js"
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:3000/sg-creative-studio.html"
echo CREATE HUB opened in your browser.
echo Keep the server window open while using the website.
