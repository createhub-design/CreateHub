CREATE HUB — SERVER-SIDE OWNER ACCESS (LOCAL v1)
================================================

REQUIRES
--------
- Windows: Node.js 22.5 or newer (https://nodejs.org/)
- Keep this folder private on your computer.

START
-----
1. Extract the whole ZIP into a new folder. Keep the old website folder as a backup.
2. Double-click START-CREATE-HUB.bat.
3. Open http://127.0.0.1:3000/sg-creative-studio.html (the batch file should open it).
4. Press Alt+Shift+A to open owner login. The server stores only a salted scrypt password hash. If you need to reset an existing owner password, close the server and run RESET-OWNER-PASSWORD.bat in this same folder; choose a strong password when prompted. It resets only the password and preserves website content. The password is not stored in a plaintext text file.
5. Owner session expires after 8 hours; use Alt+Shift+A to log out/lock.

SERVER-SIDE SECURITY INCLUDED
-----------------------------
- Node.js HTTP server; no third-party npm packages required.
- SQLite database file (createhub.sqlite) stores the owner password hash, sessions, and website content. The owner password is stored as a salted scrypt hash in SQLite; no plaintext owner password is shipped in this ZIP.
- Password is hashed server-side using scrypt with a random salt; plaintext password is not stored.
- Opaque random session cookie is HttpOnly, SameSite=Strict, and expires after 8 hours.
- Login throttling: 5 consecutive failed attempts block login for 15 minutes per local server IP; the attempt counter is corrected to increment properly.
- Content writes/deletes are checked by the server; an unauthenticated visitor cannot save edits to server content through the API.
- Website pages remain public/read-only; visitors can view content. Existing posts, photo controls, offers, themes and customizer UI remain in the original HTML pages.
- A database backup is created before explicit legacy import.

IMPORTANT DATA MIGRATION NOTE
-----------------------------
Your old website was opened as local HTML files. Browser localStorage under file:// is separate from the localhost server origin, and its contents are NOT included in an HTML ZIP. To preserve the old posts/photos/customize/offers data, follow LEGACY-DATA-EXPORT.txt and then use /migration-import.html. Data URI images are included as JSON strings.

The pages automatically send protected content changes to the server after owner login. Once server data is initialized, the server database becomes authoritative and pages hydrate from it. Theme mode remains a local browser preference.

RUNNING LOCALLY VS PUBLISHING
-----------------------------
Local mode intentionally binds to 127.0.0.1. For a deployment platform that requires binding to all interfaces, set HOST=0.0.0.0 and use the platform-provided PORT. Do not expose this server directly to the internet: publish it only behind the host's HTTPS reverse proxy.

Before public launch:
1. Reset the owner password using RESET-OWNER-PASSWORD.bat on your private local copy, then upload the resulting database securely. Never upload the ZIP or database to a public file-sharing location.
2. Use a Node.js host (Node.js 22.5+). InfinityFree shared PHP hosting does not run this Node.js server as-is.
3. Enable HTTPS at the hosting provider/reverse proxy. The server now checks same-origin requests against the request host and sets the Secure session-cookie flag when HTTPS is detected through the TLS connection or X-Forwarded-Proto.
4. Configure persistent storage for createhub.sqlite and the public/order-uploads directory. Ephemeral filesystems can lose orders' uploaded references and owner content after a restart/redeploy. Keep database backups outside the public web directory.
5. Confirm the host forwards X-Forwarded-Proto correctly, provides persistent disk, and supports a long-running Node.js service. Do not trust arbitrary client-supplied forwarding headers on a directly exposed server.
6. Test the live home, Graphic Design and Photo Editing pages, owner login/editing, WhatsApp links, and a small reference-file upload. Also test restore from a backup before relying on the site.

The ZIP is still a deployment starter, not a security certification. Hosting-provider configuration, HTTPS, persistent storage, password reset, and a live smoke test are required before public launch.

BACKUP / RESTORE
----------------
Stop the server (Ctrl+C) before copying createhub.sqlite and createhub.sqlite-wal/shm files, or use the built-in backup created by migration. Keep backups private. If you forget the owner password, do not delete the database casually: it contains your site data. A controlled password-reset procedure should be done with a database backup first.

LIMITATIONS
-----------
- This is a local server-side authentication/data-storage starter package, not a production security certification.
- If you have legacy data stored only in the old file:// browser origin, it must be exported/imported manually as described above.
- Test the pages after import, especially large images, offers, and customizer changes. Do not delete your old folder until verified.
