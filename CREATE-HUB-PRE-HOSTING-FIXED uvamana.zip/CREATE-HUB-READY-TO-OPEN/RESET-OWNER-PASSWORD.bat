@echo off
cd /d "%~dp0"
echo CREATE HUB owner password reset
echo.
echo IMPORTANT: Close the CREATE HUB server Command Prompt window before continuing.
echo This resets only the owner login password. Website posts and data are preserved.
echo You will be asked to type a new strong password twice.
echo The password is NOT saved to a text file.
echo.
pause
where node >nul 2>nul
if errorlevel 1 (echo Node.js is required.& pause & exit /b 1)
node reset-owner.js
if errorlevel 1 (echo.
echo Reset did not complete. Read the message above.& pause & exit /b 1)
echo.
echo Now double-click START-CREATE-HUB.bat and open http://127.0.0.1:3000/sg-creative-studio.html
echo Press Alt+Shift+A and enter the new password you chose.
pause
