'use strict';
// Resets only the CREATE HUB owner password. Website content is preserved.
// Password is prompted interactively and is never written to a plaintext file.
const readline = require('node:readline/promises');
const { stdin: input, stdout: output } = require('node:process');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { DatabaseSync } = require('node:sqlite');
const scrypt = promisify(crypto.scrypt);
function passwordStrong(p) {
  if (p.length < 16) return false;
  let n = 0;
  if (/[a-z]/.test(p)) n++;
  if (/[A-Z]/.test(p)) n++;
  if (/[0-9]/.test(p)) n++;
  if (/[^A-Za-z0-9]/.test(p)) n++;
  return n >= 3 && !/(.)\1{5,}/.test(p) && !/(password|qwerty|123456|admin)/i.test(p);
}
(async () => {
  const rl = readline.createInterface({ input, output });
  let db;
  try {
    console.log('CREATE HUB owner password reset');
    console.log('Choose a new password of at least 16 characters using at least 3 character types.');
    console.log('Do not reuse a password from another account. Your password will not be saved to a text file.');
    const password = await rl.question('New owner password: ');
    if (!passwordStrong(password)) throw new Error('Password does not meet the strength rules. Use 16+ characters, 3 character types, and avoid common words.');
    const confirm = await rl.question('Type the new password again: ');
    if (password !== confirm) throw new Error('Passwords do not match. No changes were made.');
    const dbPath = path.join(__dirname, 'createhub.sqlite');
    const fs = require('node:fs');
    if (!fs.existsSync(dbPath)) throw new Error('No createhub.sqlite found. Start the server once first, or use the package in its original folder.');
    db = new DatabaseSync(dbPath);
    const table = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='admin'").get();
    if (!table) throw new Error('This does not look like a CREATE HUB database. No changes were made.');
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = (await scrypt(password, salt, 64)).toString('hex');
    db.prepare('INSERT INTO admin(id,salt,hash,created_at) VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET salt=excluded.salt, hash=excluded.hash, created_at=excluded.created_at').run(salt, hash, new Date().toISOString());
    db.prepare('DELETE FROM sessions').run();
    db.prepare('DELETE FROM attempts').run();
    console.log('Owner password reset successfully. Website content was not changed.');
    console.log('Restart the server and log in using the new password you just entered.');
  } finally {
    if (db) db.close();
    rl.close();
  }
})().catch(e => { console.error('Password reset failed:', e.message); process.exitCode = 1; });
